insert [Vendeg] ([USERNEV],[NEV],[EMAIL],[SZAML_CIM],[SZUL_DAT])
select N'adam1',N'Kiss Ádám',N'ádám.kiss@mail.hu',N'5630 Békés Szolnoki út 8.','1991-12-28' UNION ALL
select N'adam3',N'Barkóci Ádám',N'adam3@gmail.com',N'3910 Tokaj Dózsa György utca 37.','1970-06-07' UNION ALL
select N'adam4',N'Bieniek Ádám',N'ádám.bieniek@mail.hu',N'8630 Balatonboglár Juhászföldi út 1.','1976-08-01' UNION ALL
select N'agnes',N'Lengyel Ágnes',N'agnes@gmail.com',N'5200 Törökszentmiklós Deák Ferenc út 5.','1979-12-10' UNION ALL
select N'agnes3',N'Hartyánszky Ágnes',N'agnes3@gmail.com',N'6430 Bácsalmás Posta köz 2.','1967-04-11' UNION ALL
select N'AGNESH',N'Horváth Ágnes',N'AGNESH@gmail.com',N'8200 Veszprém Rákóczi utca 21.','1981-12-24' UNION ALL
select N'AGNESK',N'Kovács Ágnes',N'AGNESK@gmail.com',N'1084 Budapest Endrődi Sándor utca 47.','1988-10-02' UNION ALL
select N'akos',N'Bíró Ákos',N'ákos.bíró@mail.hu',N'9023 Győr Kossuth Lajos utca 47/b.','1982-04-24' UNION ALL
select N'aladar',N'Dunai Aladár',N'aladár.dunai@mail.hu',N'5931 Nagyszénás Árpád utca 23.','1980-11-01' UNION ALL
select N'alexandra',N'Bagóczki Alexandra',N'alexandra.bagóczki@mail.hu',N'2381 Táborfalva Petőfi utca 1/2.','1992-03-25' UNION ALL
select N'andi',N'Maródi Andrea',N'andrea.maródi@mail.hu',N'5465 Cserkeszőlő Árpád utca 4.','1968-05-07' UNION ALL
select N'andras2',N'Tóth András',N'andrás.tóth@mail.hu',N'4071 Egyek Petőfi utca 30.','1997-10-31' UNION ALL
select N'andras21',N'Molnár András',N'andrás.molnár@mail.hu',N'7900 Szigetvár Rákóczi utca 67.','1977-11-16' UNION ALL
select N'andras3',N'Vígh András',N'andrás.vígh@mail.hu',N'1118 Budapest Arany János utca 1.','1971-04-02' UNION ALL
select N'andras4',N'Back András',N'andras4@gmail.com',N'3783 Edelény Fő út 169.','1984-04-07' UNION ALL
select N'andras41',N'Komjáti András',N'andras41@gmail.com',N'5065 Nagykörű Kossuth út 24.','1997-10-25' UNION ALL
select N'ANDRASE',N'Erdei András',N'ANDRASE@gmail.com',N'5071 Besenyszög Szolnoki út 8.','1997-05-29' UNION ALL
select N'ANDRASN',N'Nagy András',N'andrás.nagy@mail.hu',N'6500 Baja Fő út 169.','1980-09-05' UNION ALL
select N'andrea',N'Kiss Andrea',N'andrea.kiss@mail.hu',N'1113 Budapest Petőfi Sándor utca 87.','1993-03-25' UNION ALL
select N'andrea3',N'Szomor Andrea',N'andrea3@gmail.com',N'7960 Sellye Bécsi utca 82.','1996-05-10' UNION ALL
select N'andrea4',N'Neizer Andrea',N'andrea4@gmail.com',N'1124 Budapest Kiss u. 8.','1981-05-17' UNION ALL
select N'ANDREAT',N'Tornyos Andrea',N'ANDREAT@gmail.com',N'6131 Szank Bécsi utca 82.','1986-11-14' UNION ALL
select N'anett3',N'Pivarcsi Anett',N'anett.pivarcsi@mail.hu',N'1149 Budapest Fő út 60.','1967-01-03' UNION ALL
select N'aniko',N'Tóth Anikó',N'aniko@gmail.com',N'2085 Pilisvörösvár Deák Ferenc út 5.','1973-06-03' UNION ALL
select N'aniko4',N'Böröcz Anikó',N'aniko4@gmail.com',N'2484 Agárd Petőfi Sándor tér 1.','1978-03-26' UNION ALL
select N'ANIKOS',N'Simon Anikó',N'ANIKOS@gmail.com',N'5137 Jászkisér Bécsi utca 82.','1988-12-14' UNION ALL
select N'anita',N'Hamvay-Kovács Anita',N'anita.hamvay-kovács@mail.hu',N'7220 Sarkad Táncsics utca 19.','1971-03-20' UNION ALL
select N'annamaria1',N'Szűcs Annamária',N'annamária.szűcs@mail.hu',N'1191 Budapest Rendeki utca 21.','1990-04-27' UNION ALL
select N'ANNAMARIAR',N'Regős Annamária',N'ANNAMARIAR@gmail.com',N'8283 Káptalantóti Petőfi Sándor tér 1.','1977-09-26' UNION ALL
select N'aron2',N'Jakab Áron',N'aron2@gmail.com',N'7133 Fadd Bajcsy-Zsilinszky utca 4.','1971-04-26' UNION ALL
select N'ARONK',N'Kelemen Áron',N'áron.kelemen@mail.hu',N'8200 Veszprém Petőfi utca 8.','1989-08-10' UNION ALL
select N'arpad2',N'Ötvös Árpád',N'árpád.ötvös@mail.hu',N'2600 Vác Padragi út 158.','1990-06-08' UNION ALL
select N'ARPADH',N'Horváth Árpád',N'árpád.horváth@mail.hu',N'7349 Szászvár Dózsa György u. 1.','1990-05-18' UNION ALL
select N'ARPADM',N'Móricz Árpád',N'árpád.móricz@mail.hu',N'3910 Tokaj Rákóczi utca 67.','1986-04-20' UNION ALL
select N'attila',N'Csóti Attila',N'attila@gmail.com',N'3000 Hatvan Bajcsy-Zsilinszky utca 4.','1979-12-25' UNION ALL
select N'attila1',N'Gulyás Attila',N'attila.gulyás@mail.hu',N'3881 Abaújszántó Szolnoki út 8.','1982-08-16' UNION ALL
select N'attila4',N'Baróti Attila',N'attila.baróti@mail.hu',N'7149 Báta Arany János utca 3.','1975-11-06' UNION ALL
select N'ATTILAO',N'Opra Attila',N'ATTILAO@gmail.com',N'8283 Káptalantóti Rákóczi út 200.','1995-05-08' UNION ALL
select N'balazs1',N'Bozsik Balázs',N'balázs.bozsik@mail.hu',N'2300 Ráckeve Bécsi utca 82.','1992-11-03' UNION ALL
select N'balazs2',N'Szűcs Balázs',N'balázs.szűcs@mail.hu',N'3170 Szécsény Szabadság utca 95.','1984-10-31' UNION ALL
select N'balazs3',N'Bakódy Balázs',N'balazs3@gmail.com',N'2131 Göd Arany János utca 1.','1986-09-09' UNION ALL
select N'balint',N'Horváth Bálint',N'balint@gmail.com',N'6646 Tömörkény Endrődi Sándor utca 47.','1996-03-17' UNION ALL
select N'balint1',N'Molnár Bálint',N'balint1@gmail.com',N'9181 Kimle Fő út 169.','1989-08-24' UNION ALL
select N'balint2',N'Vukasinovity Bálint',N'balint2@gmail.com',N'2330 Dunaharaszti Béke utca 7.','1997-09-03' UNION ALL
select N'balu',N'Endresz Bálint',N'bálint.endresz@mail.hu',N'3973 Cigánd Fő út 169.','1976-08-01' UNION ALL
select N'beata4',N'Bagi Beáta',N'beáta.bagi@mail.hu',N'8477 Tüskevár Felszabadulás utca 32.','1994-03-19' UNION ALL
select N'BEATRIXK',N'Kerényi Beatrix',N'beatrix.kerényi@mail.hu',N'7396 Magyarszék Kossuth Lajos utca 47/b.','1972-04-06' UNION ALL
select N'BEATRIXS',N'Szekendi Beatrix',N'beatrix.szekendi@mail.hu',N'4060 Balmazújváros Jászai tér 21.','1981-04-06' UNION ALL
select N'BELAF',N'Farkas Béla',N'BELAF@gmail.com',N'5530 Vésztő Petőfi Sándor utca 3.','1995-02-24' UNION ALL
select N'bence',N'Győrffy Bence',N'bence@gmail.com',N'6900 Makó Árpád utca 23.','1987-07-09' UNION ALL
select N'BENCEB',N'Bajusz Bence',N'bence.bajusz@mail.hu',N'8391 Sármellék Fő utca 56.','1973-06-21' UNION ALL
select N'bernadett1',N'Simon Bernadett',N'bernadett1@gmail.com',N'2300 Ráckeve Fő utca 108.','1984-10-13' UNION ALL
select N'bernadett2',N'Kovács Bernadett',N'bernadett.kovács@mail.hu',N'4200 Hajdúszoboszló Fő út 122.','1996-08-20' UNION ALL
select N'BERNADETTO',N'Orbán Bernadett',N'bernadett.orbán@mail.hu',N'5085 Rákóczifalva Arany János utca 1.','1987-12-07' UNION ALL
select N'bertalan',N'Csiger Bertalan',N'bertalan@gmail.com',N'1192 Budapest Fő út 169.','1977-10-15' UNION ALL
select N'brigitta',N'Székely Brigitta',N'brigitta.székely@mail.hu',N'2462 Martonvásár Fő utca 47.','1978-09-13' UNION ALL
select N'brigitta3',N'Pataki Brigitta',N'brigitta.pataki@mail.hu',N'2730 Albertirsa Rendeki utca 21.','1991-05-23' UNION ALL
select N'csongor3',N'Nagymihály Csongor',N'csongor.nagymihály@mail.hu',N'9181 Kimle Deák Ferenc út 5.','1984-03-05' UNION ALL
select N'dani',N'Vörös Dániel',N'daniel@gmail.com',N'7150 Bonyhád Dózsa György u. 1.','1986-10-14' UNION ALL
select N'daniel',N'Rácz Dániel',N'dániel.rácz@mail.hu',N'9181 Kimle Szabadság tér 9.','1978-11-28' UNION ALL
select N'daniel1',N'Keszler Dániel',N'dániel.keszler@mail.hu',N'3580 Tiszaújváros Kossuth Lajos utca 6.','1969-07-16' UNION ALL
select N'david',N'Ambrus Dávid',N'david@gmail.com',N'1149 Budapest Fő út 18.','1974-02-11' UNION ALL
select N'david1',N'Sobják Dávid',N'david1@gmail.com',N'5083 Kengyel Arany János utca 3.','1970-08-16' UNION ALL
select N'david4',N'Berta Dávid',N'david4@gmail.com',N'3500 Miskolc Balatoni út 12.','1990-10-08' UNION ALL
select N'debora',N'Barna Debóra',N'debóra.barna@mail.hu',N'1155 Budapest Fő út 169.','1976-10-14' UNION ALL
select N'denes',N'Tömböly Dénes',N'denes@gmail.com',N'2400 Dunaújváros Kossuth út 39.','1975-03-14' UNION ALL
select N'dora3',N'Sarodi Dóra',N'dóra.sarodi@mail.hu',N'2855 Bokod Fő út 18.','1995-05-18' UNION ALL
select N'edit',N'Bittmann Edit',N'edit.bittmann@mail.hu',N'6077 Orgovány Fő utca 60.','1984-04-20' UNION ALL
select N'emese',N'Kuruc Emese',N'emese.kuruc@mail.hu',N'6700 Szeged Rákóczi utca 67.','1989-08-10' UNION ALL
select N'eszter',N'Molnár Eszter',N'eszter.molnár@mail.hu',N'6800 Hódmezővásárhely Fő út 77.','1987-05-10' UNION ALL
select N'eszter2',N'Balogh Eszter',N'eszter.balogh@mail.hu',N'6760 Kistelek Kossuth utca 11.','1998-01-31' UNION ALL
select N'eszter4',N'Fülöp Eszter',N'eszter.fülöp@mail.hu',N'3643 Dédestapolcsány Kossuth Lajos utca 47/b.','1993-06-28' UNION ALL
select N'ESZTERE',N'Érsek Eszter',N'eszter.érsek@mail.hu',N'6785 Pusztamérges Kossuth Lajos utca 6.','1978-08-28' UNION ALL
select N'eva',N'Enyedi Éva',N'eva@gmail.com',N'4231 Bököny Petőfi utca 8.','1967-06-30' UNION ALL
select N'eva2',N'Perlinger Éva',N'eva2@gmail.com',N'9653 Répcelak Bécsi utca 82.','1971-08-19' UNION ALL
select N'EVAV',N'Viktor Éva',N'EVAV@gmail.com',N'6913 Csanádpalota Arany János utca 3.','1980-12-26' UNION ALL
select N'ferenc1',N'Orosz Ferenc',N'ferenc.orosz@mail.hu',N'5061 Tiszasüly Arany János utca 3.','1983-10-08' UNION ALL
select N'fruzsina4',N'Frank Fruzsina',N'fruzsina4@gmail.com',N'9700 Szombathely Szabadság utca 95.','1996-08-16' UNION ALL
select N'gabor1',N'Köves Gábor',N'gabor1@gmail.com',N'6762 Sándorfalva Árpád utca 23.','1973-07-15' UNION ALL
select N'gabor4',N'Telek Gábor',N'gábor.telek@mail.hu',N'9071 Görbeháza Fő út 169.','1987-03-15' UNION ALL
select N'GABORS',N'Szöllősi Gábor',N'GABORS@gmail.com',N'3630 Putnok Kossuth utca 27.','1990-05-31' UNION ALL
select N'gabriella1',N'Nagy Gabriella',N'gabriella1@gmail.com',N'1077 Budapest Dob utca 1','1982-11-01' UNION ALL
select N'gabriella10',N'Vida Gabriella',N'gabriella10@gmail.com',N'2484 Agárd Arany János utca 3.','1969-06-18' UNION ALL
select N'georgij',N'Nyíri Georgij',N'georgij.nyíri@mail.hu',N'8391 Sármellék Grassalkovich út 10.','1983-02-23' UNION ALL
select N'gusztav',N'Bárci Gusztáv',N'gusztav@gmail.com',N'3643 Dédestapolcsány Endrődi Sándor utca 47.','1967-02-25' UNION ALL
select N'GYONGYIK',N'Kornseé Gyöngyi',N'gyöngyi.kornseé@mail.hu',N'8800 Nagykanizsa Fő út 60.','1974-06-07' UNION ALL
select N'GYORGYO',N'Oroszi György',N'GYORGYO@gmail.com',N'7220 Sarkad Dózsa György u. 1.','1980-03-23' UNION ALL
select N'henrik3',N'Nádudvari Henrik',N'henrik.nádudvari@mail.hu',N'1077 Budapest Tanácsköztársaság tér 1.','1986-12-05' UNION ALL
select N'IBOLYAA',N'Andor Ibolya',N'ibolya.andor@mail.hu',N'9023 Győr Posta köz 2.','1983-11-27' UNION ALL
select N'ilona3',N'Bosnyák Ilona',N'ilona3@gmail.com',N'2483 Gárdony Posta köz 2.','1990-08-06' UNION ALL
select N'imre',N'Búza Imre',N'imre.búza@mail.hu',N'9181 Kimle Petőfi Sándor tér 1.','1988-09-30' UNION ALL
select N'imre1',N'Papp Imre',N'imre.papp@mail.hu',N'1077 Budapest Szolnoki út 8.','1976-06-25' UNION ALL
select N'istvan',N'Soós István',N'istvan@gmail.com',N'2370 Dabas Kossuth utca 27.','1986-06-28' UNION ALL
select N'istvan1',N'Vizi István',N'istván.vizi@mail.hu',N'7086 Ozora Rákóczi utca 1.','1997-12-01' UNION ALL
select N'ISTVANV',N'Varga István',N'ISTVANV@gmail.com',N'6320 Solt Hősök tere 11.','1989-04-09' UNION ALL
select N'janos3',N'Harangozó János',N'janos3@gmail.com',N'8700 Marcali Petőfi Sándor tér 1.','1967-11-02' UNION ALL
select N'JANOSG',N'Giliga János',N'JANOSG@gmail.com',N'3300 Eger Deák Ferenc út 5.','1975-01-03' UNION ALL
select N'JANOSP',N'Pálinkás János',N'JANOSP@gmail.com',N'5920 Csorvás Padragi út 158.','1984-10-12' UNION ALL
select N'jozsef',N'Gergely József',N'jozsef@gmail.com',N'6050 Lajosmizse Fő út 18.','1985-11-01' UNION ALL
select N'jozsef2',N'Vajda József',N'józsef.vajda@mail.hu',N'6700 Szeged Baracsi László utca 14.','1978-09-04' UNION ALL
select N'JOZSEFG',N'Gyuris József',N'józsef.gyuris@mail.hu',N'2660 Balassagyarmat Petőfi utca 1/2.','1975-05-26' UNION ALL
select N'JUDITH',N'Hídasi Judit',N'JUDITH@gmail.com',N'2100 Gödöllő Fő út 169.','1997-07-12' UNION ALL
select N'julia',N'Tóth Júlia',N'julia@gmail.com',N'5310 Kisújszállás Árpád utca 4.','1993-03-02' UNION ALL
select N'julia4',N'Nagy Júlia',N'julia4@gmail.com',N'7000 Sárbogárd Jászai tér 21.','1985-08-11' UNION ALL
select N'julianna4',N'Szabó Julianna',N'julianna4@gmail.com',N'6700 Szeged Kossuth Lajos utca 6.','1990-09-29' UNION ALL
select N'kata',N'Gondos Katalin',N'katalin.gondos@mail.hu',N'8237 Tihany Kossuth Lajos utca 6.','1968-06-22' UNION ALL
select N'katalin',N'Horváth Katalin',N'katalin.horváth@mail.hu',N'2424 Előszállás Rákóczi út 200.','1968-01-01' UNION ALL
select N'katalin4',N'Kertész Katalin',N'katalin4@gmail.com',N'2800 Tatabánya Búvár utca 4.','1986-04-13' UNION ALL
select N'kati',N'Zatykó Katalin',N'katalin.zatykó@mail.hu',N'7511 Ötvöskónyi Kossuth Lajos utca 6.','1995-05-01' UNION ALL
select N'katka',N'Kovács Katalin',N'katalin.kovács@mail.hu',N'8254 Kővágóörs Petőfi utca 22.','1975-03-31' UNION ALL
select N'klaudia2',N'Bakó Klaudia',N'klaudia.bakó@mail.hu',N'8254 Kővágóörs Kossuth Lajos utca 6.','1982-04-16' UNION ALL
select N'kornel4',N'Lukács Kornél',N'kornél.lukács@mail.hu',N'2053 Herceghalom Bécsi utca 82.','1975-09-30' UNION ALL
select N'kristof4',N'Poprádi Kristóf',N'kristof4@gmail.com',N'8220 Balatonalmádi Mészáros utca 7.','1984-01-15' UNION ALL
select N'kriszti',N'Horváth Krisztina',N'kriszti@gmail.com',N'6060 Tiszakécske Árpád utca 4.','1978-06-12' UNION ALL
select N'krisztian4',N'Czérna Krisztián',N'krisztián.czérna@mail.hu',N'1107 Budapest Dózsa György utca 37.','1970-08-01' UNION ALL
select N'KRISZTIANM',N'Mogyródi Krisztián',N'KRISZTIANM@gmail.com',N'9155 Lébény Jászai tér 21.','1968-05-27' UNION ALL
select N'krisztina',N'Szedlár Krisztina',N'krisztina@gmail.com',N'6646 Tömörkény Arany János utca 1.','1979-05-10' UNION ALL
select N'krisztina1',N'Bori Krisztina',N'krisztina.bori@mail.hu',N'2115 Vácszentlászló Fő utca 47.','1969-10-13' UNION ALL
select N'KRISZTINAG',N'Gyárfás Krisztina',N'KRISZTINAG@gmail.com',N'6762 Sándorfalva Arany János utca 1.','1987-09-19' UNION ALL
select N'lajos',N'Kiss Lajos',N'lajos.kiss@mail.hu',N'1077 Budapest Dob utca 1','1978-10-31' UNION ALL
select N'lala',N'Nagymihály Lajos',N'lajos.nagymihály@mail.hu',N'8638 Balatonlelle Rákóczi út 200.','1997-02-24' UNION ALL
select N'laszlo1',N'Farkas László',N'lászló.farkas@mail.hu',N'5200 Törökszentmiklós Rendeki utca 21.','1967-10-30' UNION ALL
select N'laszlo2',N'Móra László',N'lászló.móra@mail.hu',N'9970 Szentgotthárd Petőfi utca 1/2.','1975-02-19' UNION ALL
select N'LASZLOA',N'Antal László',N'lászló.antal@mail.hu',N'2484 Agárd Bécsi utca 82.','1969-06-29' UNION ALL
select N'LASZLON',N'Nagy László',N'lászló.nagy@mail.hu',N'1173 Budapest Jászai tér 21.','1969-04-12' UNION ALL
select N'maria1',N'Baráth Mária',N'mária.baráth@mail.hu',N'1047 Budapest Posta köz 2.','1995-11-19' UNION ALL
select N'mark',N'Kispál Márk',N'márk.kispál@mail.hu',N'1086 Budapest Juhászföldi út 1.','1996-01-23' UNION ALL
select N'MARKH',N'Horváth Márk',N'márk.horváth@mail.hu',N'4400 Nyíregyháza Badacsonyi utca 12.','1997-09-23' UNION ALL
select N'marton',N'Kalacsi Márton',N'marton@gmail.com',N'5137 Jászkisér Fő út 169.','1989-06-24' UNION ALL
select N'MATEK',N'Koza Máté',N'máté.koza@mail.hu',N'1011 Budapest Központi telep 3.','1997-02-28' UNION ALL
select N'matyas2',N'Botka Mátyás',N'matyas2@gmail.com',N'2700 Cegléd Kossuth Lajos utca 6.','1972-07-07' UNION ALL
select N'MATYASS',N'Szilágyi Mátyás',N'mátyás.szilágyi@mail.hu',N'9023 Győr Kossuth Lajos utca 6.','1975-03-22' UNION ALL
select N'MIHALYJ',N'Juhász Mihály',N'mihály.juhász@mail.hu',N'6786 Ruzsa Rákóczi utca 1.','1979-10-12' UNION ALL
select N'miklos2',N'Gondos Miklós',N'miklos2@gmail.com',N'2100 Gödöllő Árpád utca 23.','1995-10-07' UNION ALL
select N'MIKLOSB',N'Balla Miklós',N'miklós.balla@mail.hu',N'4060 Balmazújváros Szent István utca 2.','1979-02-16' UNION ALL
select N'MONIKAM',N'Mohos Mónika',N'mónika.mohos@mail.hu',N'2241 Sülysáp Baracsi László utca 14.','1974-10-01' UNION ALL
select N'NANDORF',N'Fő Nándor',N'nándor.fő@mail.hu',N'5920 Csorvás Bécsi utca 82.','1968-11-12' UNION ALL
select N'nikolett3',N'Horváth Nikolett',N'nikolett3@gmail.com',N'1072 Budapest Arany János utca 1.','1981-09-29' UNION ALL
select N'nikoletta4',N'Kő Nikoletta',N'nikoletta4@gmail.com',N'5537 Zsadány Fő út 18.','1972-01-10' UNION ALL
select N'NIKOLETTAT',N'Tatár Nikoletta',N'nikoletta.tatár@mail.hu',N'1067 Budapest Győri utca 12.','1997-10-19' UNION ALL
select N'norbert',N'Szűcs Norbert',N'norbert@gmail.com',N'5071 Besenyszög Győri utca 12.','1969-07-17' UNION ALL
select N'norbert2',N'Hegedűs Norbert',N'norbert.hegedűs@mail.hu',N'2081 Piliscsaba Rendeki utca 21.','1991-07-17' UNION ALL
select N'norbert4',N'Mile Norbert',N'norbert4@gmail.com',N'3973 Cigánd Bajcsy-Zsilinszky utca 4.','1983-06-15' UNION ALL
select N'norbert5',N'Béres Norbert',N'norbert5@gmail.com',N'8640 Fonyód Bajcsy-Zsilinszky utca 4.','1975-07-27' UNION ALL
select N'pal',N'Barabás Pál',N'pál.barabás@mail.hu',N'1183 Budapest Szolnoki út 8.','1968-02-06' UNION ALL
select N'peter1',N'Kozma Péter',N'peter1@gmail.com',N'6913 Csanádpalota Központi telep 3.','1976-03-18' UNION ALL
select N'peter2',N'Bozsó Péter',N'peter2@gmail.com',N'4800 Vásárosnamény Zombori út 2/A','1976-01-26' UNION ALL
select N'peter3',N'Szalai Péter',N'peter3@gmail.com',N'1155 Budapest Arany János utca 3.','1983-07-18' UNION ALL
select N'peter4',N'Bíró Péter',N'péter.bíró@mail.hu',N'5137 Jászkisér Rákóczi utca 67.','1985-09-01' UNION ALL
select N'PETERB',N'Berendi Péter',N'péter.berendi@mail.hu',N'3980 Sátoraljaújhely Vasút utca 4/10.','1969-01-01' UNION ALL
select N'polla',N'Palágyi Polla',N'polla@gmail.com',N'2484 Agárd Fő út 18.','1994-02-04' UNION ALL
select N'rajmond4',N'Rácz Rajmond',N'rajmond.rácz@mail.hu',N'9155 Lébény Petőfi utca 1/2.','1993-09-25' UNION ALL
select N'reka4',N'Szikszai Réka',N'réka.szikszai@mail.hu',N'8254 Kővágóörs Templom utca 73.','1969-11-27' UNION ALL
select N'RENATAK',N'Kardos Renáta',N'renáta.kardos@mail.hu',N'7086 Ozora Bécsi utca 82.','1988-05-17' UNION ALL
select N'RENATAS',N'Szirmai Renáta',N'RENATAS@gmail.com',N'2053 Herceghalom Kossuth utca 27.','1991-03-26' UNION ALL
select N'robert2',N'Patay Róbert',N'robert2@gmail.com',N'2370 Dabas Rákóczi utca 21.','1977-01-08' UNION ALL
select N'ROBERTI',N'Iván Róbert',N'róbert.iván@mail.hu',N'2377 Örkény Petőfi Sándor utca 3.','1967-07-02' UNION ALL
select N'ROBERTP',N'Pásztor Róbert',N'ROBERTP@gmail.com',N'5137 Jászkisér Ady Endre út 27.','1972-05-16' UNION ALL
select N'roland',N'Tóth Roland',N'roland@gmail.com',N'2000 Szentendre Fő út 169.','1968-03-21' UNION ALL
select N'roland1',N'Ferencz Roland',N'roland.ferencz@mail.hu',N'2424 Előszállás Fő út 169.','1985-12-31' UNION ALL
select N'roza2',N'Bucskó Róza',N'roza2@gmail.com',N'5661 Újkígyós Arany János utca 3.','1988-12-26' UNION ALL
select N'sandor',N'Karasz Sándor',N'sandor@gmail.com',N'8283 Káptalantóti Kossuth Lajos utca 1/a.','1970-01-27' UNION ALL
select N'sandor3',N'Farkas Sándor',N'sándor.farkas@mail.hu',N'8640 Fonyód Tanácsköztársaság tér 1.','1989-01-27' UNION ALL
select N'sandor4',N'Nagy Sándor',N'sandor4@gmail.com',N'4600 Kisvárda Fő utca 47.','1997-06-11' UNION ALL
select N'sara',N'Farkas Sára',N'sára.farkas@mail.hu',N'5940 Tótkomlós Felszabadulás utca 32.','1973-04-05' UNION ALL
select N'SEBASTIANF',N'Foltényi Sebastián',N'SEBASTIANF@gmail.com',N'7960 Sellye Grassalkovich út 10.','1992-09-09' UNION ALL
select N'sebestyen',N'Rab Sebestyén',N'sebestyen@gmail.com',N'7130 Tolna Központi telep 3.','1992-03-03' UNION ALL
select N'szabolcs',N'Bodor Szabolcs',N'szabolcs.bodor@mail.hu',N'6786 Ruzsa Ady Endre út 27.','1990-07-16' UNION ALL
select N'SZABOLCSM',N'Miklós Szabolcs',N'szabolcs.miklós@mail.hu',N'1102 Budapest Fő út 169.','1980-08-11' UNION ALL
select N'SZILARDS',N'Szalai Szilárd',N'szilárd.szalai@mail.hu',N'1077 Budapest Fő út 18.','1967-09-28' UNION ALL
select N'szilvia1',N'Tari Szilvia',N'szilvia.tari@mail.hu',N'6080 Szabadszállás Bécsi utca 82.','1971-03-09' UNION ALL
select N'tamara2',N'Miklós Tamara',N'tamara.miklós@mail.hu',N'3910 Tokaj Kossuth út 39.','1980-08-11' UNION ALL
select N'tamas',N'Antal Tamás',N'tamás.antal@mail.hu',N'4440 Tiszavasvári Posta köz 2.','1984-09-05' UNION ALL
select N'TAMASF',N'Fényes Tamás',N'TAMASF@gmail.com',N'9023 Győr Arany János utca 1.','1997-11-06' UNION ALL
select N'tibor',N'Gombos Tibor',N'tibor.gombos@mail.hu',N'7100 Szekszárd Kossuth utca 77.','1993-11-28' UNION ALL
select N'tibor2',N'Dániel Tibor',N'tibor2@gmail.com',N'6646 Tömörkény Árpád utca 23.','1985-02-02' UNION ALL
select N'tihamer',N'Kazy Tihamér',N'tihamér.kazy@mail.hu',N'2370 Dabas Fő utca 60.','1991-07-05' UNION ALL
select N'timea',N'Papós Tímea',N'timea@gmail.com',N'1035 Budapest  Kossuth út 77.','1996-01-08' UNION ALL
select N'timea2',N'Dusha Tímea',N'tímea.dusha@mail.hu',N'5920 Csorvás Kossuth utca 8.','1975-08-22' UNION ALL
select N'tunde',N'Turcsik Tünde',N'tunde@gmail.com',N'7130 Tolna Fő út 122.','1974-02-12' UNION ALL
select N'valentin',N'Feró Valentin',N'valentin.feró@mail.hu',N'3895 Gönc Búvár utca 4.','1986-01-09' UNION ALL
select N'veronika4',N'Tankó Veronika',N'veronika4@gmail.com',N'6412 Balotaszállás Rendeki utca 21.','1983-08-28' UNION ALL
select N'VIKTORIAU',N'Urbán Viktoria',N'viktoria.urbán@mail.hu',N'3860 Encs Népboltsor  2.','1996-05-03' UNION ALL
select N'VIKTORK',N'Keresztúri Viktor',N'viktor.keresztúri@mail.hu',N'2532 Tokodaltáró Nagy Lajos tér 4.','1989-05-05' UNION ALL
select N'vivien3',N'Boros Vivien',N'vivien3@gmail.com',N'2117 Isaszeg Fő út 122.','1991-07-01' UNION ALL
select N'zoltan',N'Fodor Zoltán',N'zoltán.fodor@mail.hu',N'3441 Mezőkeresztes Fő utca 23.','1979-11-25' UNION ALL
select N'zoltan4',N'Barna Zoltán',N'zoltan4@gmail.com',N'8313 Balatongyörök Jászai tér 21.','1986-05-20' UNION ALL
select N'ZOLTANP',N'Pintér Zoltán',N'zoltán.pintér@mail.hu',N'6050 Lajosmizse Fő út 18.','1977-06-07' UNION ALL
select N'ZOLTANT',N'Tóth Zoltán',N'zoltán.tóth@mail.hu',N'4244 Újfehértó Posta köz 2.','1985-12-14' UNION ALL
select N'zsofi1',N'Molnár Zsófi',N'zsofi1@gmail.com',N'2730 Albertirsa Árpád utca 23.','1983-11-17' UNION ALL
select N'zsolt1',N'Pulai Zsolt',N'zsolt.pulai@mail.hu',N'8391 Sármellék Fő utca 60.','1988-05-27' UNION ALL
select N'ZSOLTJ',N'Józsa Zsolt',N'ZSOLTJ@gmail.com',N'8315 Gyenesdiás Bajcsy-Zsilinszky utca 4.','1983-09-29' UNION ALL
select N'zsuzsa',N'Pusztai Zsuzsanna',N'zsuzsanna@gmail.com',N'6783 Ásotthalom Badacsonyi utca 12.','1980-09-17' UNION ALL
select N'zsuzsa3',N'Varsányi Zsuzsa',N'zsuzsa.varsányi@mail.hu',N'8600 Siófok Árpád utca 4.','1979-03-06' UNION ALL
select N'zsuzsanna',N'Barta Zsuzsanna',N'zsuzsanna.barta@mail.hu',N'4172 Biharnagybajom Dózsa György utca 37.','1994-10-07' UNION ALL
select N'ZSUZSAV',N'Vajda Zsuzsa',N'zsuzsa.vajda@mail.hu',N'6786 Ruzsa Kossuth utca 77.','1976-12-11';