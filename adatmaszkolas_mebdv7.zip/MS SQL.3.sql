CREATE user maszkolt without login
grant SELECT ON Vendeg to maszkolt
