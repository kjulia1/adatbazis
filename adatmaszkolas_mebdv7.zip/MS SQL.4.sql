execute as user='maszkolt'
SELECT * from Vendeg
REVERT